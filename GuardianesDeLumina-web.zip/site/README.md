# Guardianes de Lumina — versión web

Abre `index.html` en un navegador para jugar. Para publicar: sube el contenido de `site/` a un servicio de hosting estático.

## Monetización
- Google AdSense para anuncios normales, una vez que el sitio cumpla los requisitos y tenga dominio/políticas adecuadas.
- Los anuncios recompensados para juegos web requieren una integración compatible; no se deben insertar anuncios falsos ni hacer clics propios.
- Añadir páginas de privacidad, cookies/consentimiento cuando corresponda y términos antes de solicitar monetización.
